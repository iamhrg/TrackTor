#!/bin/bash
gedit /etc/tor/torrc
